Homebrew Linux Port
===================
This is the Linux port of Homebrew.

The regular Homebrew software can be found at:

http://wiki.github.com/mxcl/homebrew/


Installation
------------

http://blog.frameos.org/2010/11/10/mac-homebrew-ported-to-linux/
